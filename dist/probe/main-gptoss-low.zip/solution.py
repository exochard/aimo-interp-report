"""Group probe: robust only for one evaluated configuration (gptoss-low)."""


def are_robust(model_id: str, reasoning_effort: str, problems: list[str]) -> list[bool]:
    hit = model_id == "openai/gpt-oss-120b" and reasoning_effort == "low"
    return [bool(hit) for _ in problems]
