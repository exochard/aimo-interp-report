"""Group probe: robust only for one evaluated configuration (olmo)."""


def are_robust(model_id: str, reasoning_effort: str, problems: list[str]) -> list[bool]:
    hit = model_id == "allenai/Olmo-3-7B-Think"
    return [bool(hit) for _ in problems]
