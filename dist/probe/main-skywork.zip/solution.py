"""Group probe: robust only for one evaluated configuration (skywork)."""


def are_robust(model_id: str, reasoning_effort: str, problems: list[str]) -> list[bool]:
    hit = model_id == "Skywork/Skywork-OR1-Math-7B"
    return [bool(hit) for _ in problems]
