"""Group probe: robust only for one evaluated configuration (deepseek)."""


def are_robust(model_id: str, reasoning_effort: str, problems: list[str]) -> list[bool]:
    hit = model_id == "deepseek-ai/DeepSeek-R1-0528-Qwen3-8B"
    return [bool(hit) for _ in problems]
