"""Group probe: robust only for one evaluated configuration (qwen4b)."""


def are_robust(model_id: str, reasoning_effort: str, problems: list[str]) -> list[bool]:
    hit = model_id == "Qwen/Qwen3.5-4B"
    return [bool(hit) for _ in problems]
